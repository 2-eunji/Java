
/*	 Date : 2020.05.08
   	 Author : eunji
   	 Descript : ex02_day01
   	 Version : 2.5
 */

package java0508;

public class ex02_day01 {

	public static void main(String[] args) {
		
		String name;
		name = "이은지";
		String birth;
		birth = "7월 28일";
		int age;
		age = 23;
		String adr;
		adr = "인천 남동구 구월동";
		String phone;
		phone ="010-3954-7691";
		String email;
		email ="leji02789@naver.com";
		String hobby;
		hobby ="영화시청";
		String speciality;
		speciality = "자바공부하기";
		char blood;
		blood = 'A';
		char blood2;
		blood2 = 'B';
		
		String member1;
		String member2;
		String member3;
		
		System.out.println("제 이름은 " + name + " 입니다.");
		System.out.println("제 생일은 " + birth + " 입니다.");
		System.out.println("제 나이는 " + age + "세 입니다.");
		System.out.println("제 주소는 " + adr + " 입니다.");
		System.out.println("제 핸드폰번호는 " + phone + " 입니다.");
		System.out.println("제 이메일은 " + email + " 입니다.");
		System.out.println("제 취미는 " + hobby + " 입니다.");
		System.out.println("제 특기는 " + speciality + " 입니다.");
		System.out.println("제 혈액형은 " + blood+blood2 + " 입니다.");
		
		

	}

}
