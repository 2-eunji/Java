
/*	 Date : 2020.05.08
   	 Author : eunji
   	 Descript : Java 기본설정
   	 Version : 1.1
 */

package java0508;

public class ex01_2 {
	public static void main(String[] args) {
		System.out.println("들여쓰기 연습");
		System.out.println("[ctrl] + [shift] + [F]");
	// 들여쓰기 [ctrl] + [shift] + [F]
	
		
	}
	
}
